<?php
echo "<h1>¡Hola, Mundo!</h1>";
?>