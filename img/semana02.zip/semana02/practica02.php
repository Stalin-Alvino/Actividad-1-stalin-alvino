<?php
$texto = "juan";
$numero = 30;
echo"Mi nombre es $texto y tengo $numero"
?>